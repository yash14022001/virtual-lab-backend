<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InputsController extends Controller
{
    //
}
